<?php
function esPrimo($numero) {
    if ($numero <= 1) {
        return false;
    }
    for ($i = 2; $i < $numero; $i++) {
        if ($numero % $i == 0) {
            return false;
        }
    }
    return true;
}
session_start();
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

$baseRoute = '/numerosPrimos';

if ($_SERVER['REQUEST_METHOD'] === 'GET' && $_SERVER['REQUEST_URI'] === $baseRoute) {
    $numerosPrimos = [];
    for ($i = 1; $i <= 100; $i++) {
        if (esPrimo($i)) {
            $numerosPrimos[] = $i;
        }
    }

    // Convertir el array a JSON y enviar la respuesta
    echo json_encode($numerosPrimos);
    exit;
} else {
    http_response_code(404); // Not Found
    echo json_encode(['error' => 'Ruta no encontrada']);
    exit;
}
